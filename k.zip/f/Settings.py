
from getpass import getpass

import platform, getpass

user = getpass.getuser()

OutputDirectory = r"C:\Users\{0}\AppData\Roaming\System\Output".format(user)